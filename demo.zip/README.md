## Running locally
```yarn install```
```yarn start```

## Update poll frequency using
```localstorage.pollFreq = 1000```